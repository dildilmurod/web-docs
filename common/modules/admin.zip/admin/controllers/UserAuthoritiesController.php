<?php

namespace common\modules\admin\controllers;

use common\helpers\Stat;
use common\models\MyAuthority;
use common\models\MyConfig;
use common\models\User;
use common\models\UserAuthoritiesLink;
use common\models\UserSearch;
use yii;

use yii\helpers\ArrayHelper;
use yii\helpers\Json;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * UserAuthoritiesController implements the CRUD actions for UserAuthoritiesLink model.
 */
class UserAuthoritiesController extends Controller
{
    /**
     * @return array
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all User models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ReportUsersLink model.
     * @param $id
     * @return mixed
     * @throws NotFoundHttpException
     * @internal param int $report_id
     * @internal param int $user_id
     */
    public function actionView($id)
    {
        $user = $this->findUser($id);
        $stat = new Stat();
        $hiddenServices = implode(',', explode(',', MyConfig::getValue('statHiddenServices', '173,465,332')));
        $serviceCondition = " AND type = 'semi-auto' AND is_deleted<>1 AND (invisible <> 1 OR id IN ( $hiddenServices ))";

        $data = $stat->getOrganizations(['not in','a.id',$user->getAuthoritiesId()],[],null,$serviceCondition);
        $selectedData = $stat->getOrganizations(['in','a.id',$user->getAuthoritiesId()],[],null,$serviceCondition);
        return $this->render('view', [
            'authorities' => $data,
            'userAuthorities' => $selectedData,
            'user'=> $user,
            'model' => new UserAuthoritiesLink(),
        ]);
    }

    /**
     * @param $id
     * @throws NotFoundHttpException
     */
    public function actionAdd($id)
    {
        $model = $this->findUser($id);
        $arAuthoritiesId = Yii::$app->request->post('multiSelectData',[]);
        foreach ($arAuthoritiesId as $authorityId)
        {
            $ae = new UserAuthoritiesLink();
            $ae->user_id = $model->id;
            $ae->authority_id = (int)$authorityId;
            if ($ae->validate()){
                $ae->save();
            } else {
                echo 0;
                return;
            }
        }
        echo 200;
    }

    /**
     * @param $id
     * @throws NotFoundHttpException
     */
    public function actionRemove($id)
    {
        $model = $this->findUser($id);
        $arAuthoritiesId = Yii::$app->request->post('multiSelectData',[]);
        foreach ($arAuthoritiesId as $authorityId)
        {
            $ae = UserAuthoritiesLink::deleteAll('authority_id = :orgId AND user_id = :userId',[':orgId' => (int)$authorityId, ':userId'=>$model->id]);
            if (!$ae)
            {
                echo 0;
                return;
            }
        }
        echo 200;
    }



    /**
     * Finds the ReportUsersLink model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $authority_id
     * @param integer $user_id
     * @return UserAuthoritiesLink the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($authority_id, $user_id)
    {
        if (($model = UserAuthoritiesLink::findOne(['report_id' => $authority_id, 'user_id' => $user_id])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }



    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param  integer $id The user id.
     * @return User The loaded model.
     *
     * @throws NotFoundHttpException
     */
    protected function findUser($id)
    {
        if (($model = User::findOne($id)) !== null)
        {
            return $model;
        }
        else
        {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
