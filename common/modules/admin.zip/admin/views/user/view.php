<?php
use frontend\widgets\multiSelect\MultiSelect;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\DetailView;

/* @var $this yii\web\View
 * @var $model common\models\User
 * @var $link common\models\UserAuthoritiesLink
 * @var $authorities common\models\MyAuthority[]
 * @var $userAuthorities common\models\MyAuthority[]
 */

$this->title = $model->username;
$this->params['breadcrumbs'][] = ['label' => 'Ползователи', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-view">

    <h1><?= Html::encode($this->title) ?>

    <div class="pull-right">
        <?= Html::a('Back', ['index'], ['class' => 'btn btn-warning']) ?>
        <?= Html::a('Редактировать', ['update', 'id' => $model->id], [
            'class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this user?',
                'method' => 'post',
            ],
        ]) ?>
    </div>

    </h1>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'created_at:date'         ,
            'updated_at:date'         ,
            'id'                      ,
            'public_id'               ,
            'username'                ,
            'full_name'                ,
            'email:email'             ,
            'phone'                   ,
            [
                'attribute'=>'status',
                'value' => $model->getStatusName(),
            ],
            [
                'attribute'=>'item_name',
                'value' => $model->getRoleName(),
            ],
        ],
    ]) ?>

    <?= MultiSelect::widget([
        'multiSelectJsPath' => '/js/multiselect.js',
        'valueAttribute' => 'name_'.Yii::$app->language,
        'keyAttribute' => 'id',
        'leftLabel' => 'Организации',
        'rightLabel' => 'Список связанных организации с этим пользователем',
        'data'=>$authorities,
        'selectedData'=>$userAuthorities,
        'addDataUrl'=>Url::to(['/admin/user-authorities/add', 'id' => $model->id]),
        'removeDataUrl'=>Url::to(['/admin/user-authorities/remove', 'id' => $model->id]),
        'leftButtonOptions' => ['class'=>'btn-primary'],
        'leftAllButtonOptions' => ['class'=>'btn-primary'],
        'rightButtonOptions' => ['class'=>'btn-primary'],
        'rightAllButtonOptions' => ['class'=>'btn-primary'],
        'listBoxSize' => 25
    ]);?>

</div>


