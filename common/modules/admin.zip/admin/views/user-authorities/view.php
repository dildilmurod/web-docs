<?php

use frontend\widgets\multiSelect\MultiSelect;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

/* @var $this yii\web\View
 * @var $user common\models\User
 * @var $model common\models\UserAuthoritiesLink
 * @var $authorities common\models\MyAuthority[]
 * @var $userAuthorities common\models\MyAuthority[]
 */
?>
<?= MultiSelect::widget([
    'multiSelectJsPath' => '/js/multiselect.js',
    'valueAttribute' => 'name_'.Yii::$app->language,
    'keyAttribute' => 'id',
    'leftLabel' => 'Организации',
    'rightLabel' => 'Список связанных организации с этим пользователем',
    'data'=>$authorities,
    'selectedData'=>$userAuthorities,
    'addDataUrl'=>Url::to(['/admin/user-authorities/add', 'id' => $user->id]),
    'removeDataUrl'=>Url::to(['/admin/user-authorities/remove', 'id' => $user->id]),
    'leftButtonOptions' => ['class'=>'btn-primary'],
    'leftAllButtonOptions' => ['class'=>'btn-primary'],
    'rightButtonOptions' => ['class'=>'btn-primary'],
    'rightAllButtonOptions' => ['class'=>'btn-primary'],
    'listBoxSize' => 25
]);?>